'use strict';

/*
 * Dependencies
 */
// Mongo Setup
require('dotenv').config();
const mongoDB = require('./utils/mongoDB');
mongoDB.connect();
require('./schema/Principle'); // mongoose schema
const mongoose = require('mongoose');
mongoose.Promise = global.Promise;
const Principle = mongoose.model('Principle');

// function processEvent (event, context, callback) {
//   console.log('Calling MongoDB Atlas from AWS Lambda with event: ' + JSON.stringify(event));
// }

// Cache DB connection for the duration of underlying container for this function
// let cachedDb = null;

/*
 * Entry Point
 */
exports.handler = async (event, context, callback) => {
  // var uri = process.env.MONGODB_ATLAS_CLUSTER_URI;
  // if (atlasConnectionUri != null) {
  //   processEvent(event, context, callback);
  // } else {
  //   atlasConnectionUri = uri;
  //   console.log('the Atlas connection string is ' + atlasConnectionUri);
  //   processEvent(event, context, callback);
  // }
  const responseCode = 200;
  console.log('request: ' + JSON.stringify(event));

  // if (event.body) {
  //   const body = JSON.parse(event.body);
  //   if (body.time) {
  //     time = body.time;
  //   }
  // }

  const responseBody = {
    input: event,
    context
  };

  // The output from a Lambda proxy integration must be
  // in the following JSON object. The 'headers' property
  // is for custom response headers in addition to standard
  // ones. The 'body' property  must be a JSON string. For
  // base64-encoded payload, you must also set the 'isBase64Encoded'
  // property to 'true'.
  const response = {
    statusCode: responseCode,
    headers: {
      'x-custom-header': 'my custom header value'
    },
    body: JSON.stringify(responseBody)
  };
  console.log('response: ' + JSON.stringify(response));
  return response;
};
