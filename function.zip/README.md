# Principles
Principles Microservice

# Deploy to Lambda
```
# in root directory
zip function.zip *

# upload to lambda - run from root directory of function
scripts/deploy.sh
```